package com.ust.exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
